package com.g30.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class G30JpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(G30JpaApplication.class, args);
	}

}
