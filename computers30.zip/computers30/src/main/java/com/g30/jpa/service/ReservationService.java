package com.g30.jpa.service;

import com.g30.jpa.entity.Reservation;
import com.g30.jpa.repository.ReservationRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author dmanrique
 */
@Service
public class ReservationService {

    @Autowired
    private ReservationRepository reservationRepository;

    //Metodo para consultar todos los registros (Capa de servicios)
    public List<Reservation> getReservation() {
        return reservationRepository.findAll();
    }

    //Metodo para insertar (Capa de servicios)
    public Reservation insertReservation(Reservation reservation) {
        return reservationRepository.save(reservation);
    }
    
    //Metodo para consultar una registo x su id (Capa de servicios)
    public Reservation getReservationById(Long id){
            return reservationRepository.findById(id).get();
    }

    //Metodo para eliminar (Capa de servicios)
    public void deleteReservation(Long id){
       reservationRepository.deleteById(id);               
    }
    
    public Reservation updateReservation(Reservation reservation){
        //valido si viene un id en la información de la peticion
        //si no viene retorno la entidad recibida como parametro
        if (reservation.getIdReservation()!=null){
            //valido si el id existe en la base de datos
            Optional<Reservation> opcional = reservationRepository.findById(reservation.getIdReservation());
            
            if (!opcional.isEmpty()){
                //logica
                Reservation reservationBD = opcional.get();
                reservationBD.setClient(reservation.getClient());
                reservationBD.setComputer(reservation.getComputer());
                reservationBD.setStartDate(reservation.getStartDate());
                reservationBD.setDevolutionDate(reservation.getDevolutionDate());
                reservationBD.setStatus(reservation.getStatus());
                
                return reservationRepository.save(reservationBD);
            }else{
                return reservation;
            }
        }
        return reservation;
        
    }
}
